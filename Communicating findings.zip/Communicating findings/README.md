# Prosper Loans' Dataset Exploration
## About the Dataset
For this project on Communicating Findings, I used the Loans data from Prosper. I downloaded this dataset through a link in the classroom. The link to the data is [Prosper Loans Data] (https://www.google.com/url?q=https://www.google.com/url?q%3Dhttps://s3.amazonaws.com/udacity-hosted-downloads/ud651/prosperLoanData.csv%26amp;sa%3DD%26amp;ust%3D1581581520570000&sa=D&source=editors&ust=1667739232996200&usg=AOvVaw2E61DfQzhEa9LQUBahaj61) and the link to the data descriptions is [Variable Explanations] (https://www.google.com/url?q=https://docs.google.com/spreadsheet/ccc?key%3D0AllIqIyvWZdadDd5NTlqZ1pBMHlsUjdrOTZHaVBuSlE%26usp%3Dsharing&sa=D&source=editors&ust=1667739232997224&usg=AOvVaw2COQVkd9oBH8sE2tRIarqj). The dataset consists of 113937 rows and 81 columns. Since this dataset has so many observations, I chose a few that I investigated such as term, loan status, borrower rate, borrower APR, prosper rating, prosper score, borrower state, occupation, borrower state, income range, employment status, loan amount and monthly loan payment. 

## Summary of Findings
In this analysis, I found out a strong positive relationship between borrower rate and borrower APR, with an approximate linear relationship. For the correlation between the borrower APR and borrower rate, and my variables of interest, I found interesting insights. The borrower APR and loan original amount have a negative relationship, where as the loan original amount increases the interest rate decreases. Another interesting observation was the decrease in borrower APR with increasing levels of income. The loan term when plotted on the borrower rate and borrower APR, shows that those who take long-term loans enjoy lower interest rates than those on short-term loans. With the employment status category, the employed and those under full-time jobs also enjoy lower interest rates than other categories. Additionally, those who have higher prosper scores are also charged lower interest rates those with low prosper scores. One obvious observation was on the relationship between original loan amount and the monthly loan payment. These two have a strong positive relationship, which explains that the higher the loan amount the higher the monthly loan payment. 

## Key Insights for Presentation
I started the presentation off by doing some preliminary wrangling. I then did presentation of the borrower rate and APR which was my main variable of focus. Later on I introduce the quantitative variables of interest such as loan amount, and monthly loan payment, and did the log transormations where I needed more clarity on their distributions. Here I also introduce the categorical variables I wanted to analyse such as the income ranges, loan term, employment status, and prosper score. To analyse the numerical variables I did a heatmap and scatter plots. For the categorical variables I used boxplots to see how they relate to each other. I also used a violin plot when analysing the relationship between the income range and the borrower APR.   




```python

```
